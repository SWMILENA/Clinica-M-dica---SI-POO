const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

app.use(cors());
app.use(bodyParser.json());

const db = new sqlite3.Database('./clinica.db', (err) => {
  if (err) {
    console.error('Erro ao abrir banco:', err.message);
  } else {
    console.log('Banco aberto com sucesso.');
  }
});

db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS pacientes (
    cpf TEXT PRIMARY KEY,
    nome TEXT NOT NULL
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS consultas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    cpf TEXT NOT NULL,
    medico TEXT NOT NULL,
    data TEXT NOT NULL,
    hora TEXT NOT NULL,
    FOREIGN KEY(cpf) REFERENCES pacientes(cpf)
  )`);
});

app.get('/pacientes/:cpf', (req, res) => {
  const cpf = req.params.cpf;
  db.get('SELECT * FROM pacientes WHERE cpf = ?', [cpf], (err, row) => {
    if (err) return res.status(500).json({ error: 'Erro no servidor' });
    if (row) {
      res.json({ cadastrado: true, paciente: row });
    } else {
      res.json({ cadastrado: false });
    }
  });
});

app.post('/agendar', (req, res) => {
  const { cpf, nome, medico, data, hora } = req.body;

  if (!cpf || !nome || !medico || !data || !hora) {
    return res.status(400).json({ error: 'Todos os campos são obrigatórios' });
  }

  db.get('SELECT * FROM pacientes WHERE cpf = ?', [cpf], (err, paciente) => {
    if (err) return res.status(500).json({ error: 'Erro no servidor' });

    const inserirConsulta = () => {
      db.get(
        'SELECT * FROM consultas WHERE medico = ? AND data = ? AND hora = ?',
        [medico, data, hora],
        (err, consulta) => {
          if (err) return res.status(500).json({ error: 'Erro no servidor' });
          if (consulta) {
            return res.status(409).json({ error: 'Horário já agendado para este médico' });
          } else {
            db.run(
              'INSERT INTO consultas (cpf, medico, data, hora) VALUES (?, ?, ?, ?)',
              [cpf, medico, data, hora],
              function (err) {
                if (err) return res.status(500).json({ error: 'Erro ao agendar consulta' });
                res.json({ message: 'Consulta agendada com sucesso', consultaId: this.lastID });
              }
            );
          }
        }
      );
    };

    if (!paciente) {
      db.run('INSERT INTO pacientes (cpf, nome) VALUES (?, ?)', [cpf, nome], (err) => {
        if (err) return res.status(500).json({ error: 'Erro ao cadastrar paciente' });
        inserirConsulta();
      });
    } else {
      inserirConsulta();
    }
  });
});

app.post('/cancelar', (req, res) => {
  const { cpf, data, hora } = req.body;

  if (!cpf || !data || !hora) {
    return res.status(400).json({ error: 'CPF, data e hora são obrigatórios' });
  }

  db.run('DELETE FROM consultas WHERE cpf = ? AND data = ? AND hora = ?', [cpf, data, hora], function (err) {
    if (err) return res.status(500).json({ error: 'Erro ao cancelar consulta' });

    if (this.changes === 0) {
      res.status(404).json({ error: 'Nenhuma consulta encontrada para esse CPF, data e hora' });
    } else {
      res.json({ message: 'Consulta cancelada com sucesso' });
    }
  });
});


app.get('/consultas', (req, res) => {
  const sql = `
    SELECT consultas.cpf, pacientes.nome AS nome_paciente,
           consultas.medico AS crm_medico, medicos.nome AS nome_medico,
           consultas.data, consultas.hora
    FROM consultas
    LEFT JOIN pacientes ON consultas.cpf = pacientes.cpf
    LEFT JOIN medicos ON consultas.medico = medicos.crm
    ORDER BY consultas.data, consultas.hora
  `;
  db.all(sql, [], (err, rows) => {
    if (err) {
      return res.status(500).json({ error: 'Erro ao buscar consultas' });
    }
    res.json(rows);
  });
});

// Rota para buscar histórico de consultas por CPF do paciente
app.get('/historico', (req, res) => {
  const cpf = req.query.cpf;

  if (!cpf) {
    return res.status(400).json({ error: 'CPF é obrigatório' });
  }

  const sql = `
    SELECT consultas.cpf, pacientes.nome AS nome_paciente,
           consultas.medico AS crm_medico, medicos.nome AS nome_medico,
           consultas.data, consultas.hora
    FROM consultas
    LEFT JOIN pacientes ON consultas.cpf = pacientes.cpf
    LEFT JOIN medicos ON consultas.medico = medicos.crm
    WHERE consultas.cpf = ?
    ORDER BY consultas.data DESC, consultas.hora DESC
  `;

  db.all(sql, [cpf], (err, rows) => {
    if (err) {
      return res.status(500).json({ error: 'Erro ao buscar histórico' });
    }
    console.log('Resultado do histórico:', rows);
    res.json(rows);
  });
});


app.get('/consultas', (req, res) => {
  const sql = `
    SELECT consultas.cpf, pacientes.nome, consultas.medico, consultas.data, consultas.hora
    FROM consultas
    LEFT JOIN pacientes ON consultas.cpf = pacientes.cpf
    ORDER BY consultas.data, consultas.hora
  `;
  db.all(sql, [], (err, rows) => {
    if (err) {
      return res.status(500).json({ error: 'Erro ao buscar consultas' });
    }
    res.json(rows);
  });
});

// Rota para cadastrar paciente
app.post('/pacientes', (req, res) => {
  let { nome, cpf, dataNascimento } = req.body;

  if (!nome || !cpf || !dataNascimento) {
    return res.status(400).json({ error: 'Nome, CPF e data de nascimento são obrigatórios.' });
  }

  // Remover máscara do CPF (pontos e traços)
  cpf = cpf.replace(/\D/g, '');

  // Validação simples do CPF (11 dígitos)
  if (!/^\d{11}$/.test(cpf)) {
    return res.status(400).json({ error: 'CPF inválido.' });
  }

  // Inserir paciente no banco, ou atualizar se já existir
  const sql = `
    INSERT INTO pacientes (cpf, nome)
    VALUES (?, ?)
    ON CONFLICT(cpf) DO UPDATE SET nome = excluded.nome
  `;

  db.run(sql, [cpf, nome], function (err) {
    if (err) {
      return res.status(500).json({ error: 'Erro ao salvar paciente.' });
    }
    res.json({ message: 'Paciente cadastrado com sucesso.' });
  });
});

// Criação da tabela médicos (se ainda não existir)
db.run(`CREATE TABLE IF NOT EXISTS medicos (
  crm TEXT PRIMARY KEY,
  nome TEXT NOT NULL,
  especialidade TEXT NOT NULL
)`);

// Rota para cadastrar médico
app.post('/medicos', (req, res) => {
  const { nome, crm, especialidade } = req.body;

  if (!nome || !crm || !especialidade) {
    return res.status(400).json({ error: 'Nome, CRM e especialidade são obrigatórios.' });
  }

  const sql = `
    INSERT INTO medicos (crm, nome, especialidade)
    VALUES (?, ?, ?)
    ON CONFLICT(crm) DO UPDATE SET nome = excluded.nome, especialidade = excluded.especialidade
  `;

  db.run(sql, [crm, nome, especialidade], function (err) {
    if (err) {
      return res.status(500).json({ error: 'Erro ao salvar médico.' });
    }
    res.json({ message: 'Médico cadastrado com sucesso.' });
  });
});

app.get('/medicos', (req, res) => {
  const sql = `SELECT crm, nome, especialidade FROM medicos ORDER BY nome`;
  db.all(sql, [], (err, rows) => {
    if (err) {
      return res.status(500).json({ error: 'Erro ao buscar médicos' });
    }
    res.json(rows);
  });
});



app.listen(port, () => {
  console.log(`Servidor rodando em http://localhost:${port}`);
});
